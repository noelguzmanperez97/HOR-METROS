package com.inspeccion.horometrosmina;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final int SAVE_DOCUMENT_REQUEST = 11;
    private WebView webView;
    private byte[] pendingSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(14, 21, 32));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(14, 21, 32));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // Necesario para el formulario local de confianza.
        settings.setDomStorageEnabled(true); // Mantiene guardadas las lecturas temporalmente.
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());

        // Solo cargamos el HTML incluido dentro de esta app. No necesita Internet.
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !"appassets.androidplatform.net".equals(uri.getHost());
            }
        });
        webView.addJavascriptInterface(new AndroidAppBridge(), "AndroidApp");
        webView.loadUrl(APP_URL);
    }

    private void alert(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private String safeFilename(String name, String fallback) {
        if (name == null || name.isEmpty()) return fallback;
        return name.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    private byte[] parseImage(String dataUrl) {
        String prefix = "data:image/png;base64,";
        if (dataUrl == null || !dataUrl.startsWith(prefix) || dataUrl.length() > 12_000_000) {
            return null;
        }
        try {
            return Base64.decode(dataUrl.substring(prefix.length()), Base64.DEFAULT);
        } catch (Exception ex) {
            return null;
        }
    }

    // Abre el menú nativo de Android para elegir WhatsApp u otra app.
    private void sharePng(byte[] image, String filename, String caption) {
        try {
            File directory = new File(getCacheDir(), "share");
            if (!directory.exists() && !directory.mkdirs()) throw new Exception("No se pudo crear el directorio");
            File file = new File(directory, safeFilename(filename, "horometros.png"));
            try (FileOutputStream out = new FileOutputStream(file)) { out.write(image); }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("image/png");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_TEXT, caption == null ? "Registro de horómetros" : caption);
            send.setClipData(ClipData.newRawUri("reporte", uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "Enviar reporte por WhatsApp"));
        } catch (Exception ex) {
            alert("Error al compartir: " + ex.getMessage());
        }
    }

    // Android 10+ guarda imágenes en Fotos y JSON en Descargas. En Android 8 y 9 usa el selector.
    private void saveFile(byte[] bytes, String name, String mime, boolean image) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Uri target = null;
            try {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeFilename(name, image ? "horometros.png" : "respaldo.json"));
                values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, image ?
                        Environment.DIRECTORY_PICTURES + "/Horometros" :
                        Environment.DIRECTORY_DOWNLOADS + "/Horometros");
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri collection = image ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                target = getContentResolver().insert(collection, values);
                if (target == null) throw new Exception("No se creó el archivo");
                try (OutputStream out = getContentResolver().openOutputStream(target)) {
                    if (out == null) throw new Exception("No se pudo escribir");
                    out.write(bytes);
                }
                values.clear();
                values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(target, values, null, null);
                alert(image ? "Imagen guardada en Imágenes/Horometros" : "Respaldo guardado en Descargas/Horometros");
            } catch (Exception ex) {
                if (target != null) getContentResolver().delete(target, null, null);
                alert("Error al guardar: " + ex.getMessage());
            }
        } else {
            pendingSave = bytes;
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(mime);
            intent.putExtra(Intent.EXTRA_TITLE, safeFilename(name, "reporte"));
            startActivityForResult(intent, SAVE_DOCUMENT_REQUEST);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SAVE_DOCUMENT_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSave != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("Archivo no accesible");
                    out.write(pendingSave);
                    alert("Archivo guardado correctamente");
                } catch (Exception ex) {
                    alert("Error al guardar: " + ex.getMessage());
                }
            }
            pendingSave = null;
        }
    }

    public class AndroidAppBridge {
        @JavascriptInterface
        public void sharePng(String dataUrl, String filename, String caption) {
            final byte[] data = parseImage(dataUrl);
            runOnUiThread(() -> {
                if (data == null) alert("No se pudo generar el reporte");
                else MainActivity.this.sharePng(data, filename, caption);
            });
        }
        @JavascriptInterface
        public void savePng(String dataUrl, String filename) {
            final byte[] data = parseImage(dataUrl);
            runOnUiThread(() -> {
                if (data == null) alert("No se pudo generar la imagen");
                else MainActivity.this.saveFile(data, filename, "image/png", true);
            });
        }
        @JavascriptInterface
        public void saveBackup(String content, String filename) {
            if (content == null || content.length() > 1_000_000) return;
            final byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
            runOnUiThread(() -> saveFile(bytes, filename, "application/json", false));
        }
    }
}
