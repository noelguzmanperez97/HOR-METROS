# Horómetros Mina — crear APK sin Android Studio

Esta carpeta es un **proyecto Android listo para intentar compilar en GitHub Actions**. No es la APK compilada.

Contiene la versión actual del formulario con:
- `MINETRUCKS MT` (MT 9, MT 10, MT 11).
- `DUMP TRUCK` (DUX 5).
- `FINAL TURNO`.
- Estados compactos con iconos al ingresar el horómetro.
- Descripción para compartir `REGISTRO DE HORÓMETROS (-405)` o `(-130)` según el nivel seleccionado (WhatsApp puede omitirla según su versión).
- PNG del reporte, observaciones generales, imágenes de equipos y guardado local.

## La manera más fácil: GitHub desde la computadora

1. Ve a https://github.com e inicia sesión (o crea tu cuenta).
2. Pulsa **New repository**. Nombre sugerido: `horometros-mina`. Marca **Private** y crea el repositorio.
3. Descomprime este ZIP en tu computadora.
4. En el repositorio GitHub, selecciona **Add file → Upload files**. Arrastra **todos los archivos y carpetas que están dentro** de la carpeta descomprimida (incluida `.github`, `app`, `gradle`, `build.gradle`, `settings.gradle`, `gradle.properties`). Deben quedar en la raíz del repositorio, **no** dentro de otra carpeta y **no** como un único ZIP. Presiona **Commit changes**.
5. En **Actions**, localiza **Compilar APK de Horómetros Mina**. Si aparece la opción **Run workflow**, ejecútala. Este proyecto también permite compilar automáticamente cuando subes cambios.
6. Cuando una ejecución termine con éxito (marca verde), entra en ella y baja a **Artifacts**. Descarga `Horometros-Mina-APK-Pruebas` y descomprímelo.
7. Dentro encontrarás `app-debug.apk`. Envíalo al celular de prueba e instálalo. Android puede pedir autorizar "Instalar apps desconocidas" para la aplicación desde la que abres el APK.
8. Prueba abrir sin datos móviles, llenar un horómetro, elegir un estado, generar PNG y compartirlo por WhatsApp.

## Importante sobre el archivo APK generado

- Es **APK de prueba (debug)**, no versión final de distribución.
- No necesita Internet para llenar el formulario ni generar PNG. **Enviar el mensaje a WhatsApp sí necesita conexión**.
- Los datos del formulario se guardan localmente en ese teléfono; cada compañero tiene sus propias lecturas.
- Para actualizar muchas veces sin problemas necesitas generar una **APK release firmada** y conservar siempre su clave de firma.
- No se entrega el código fuente al compartir solo la APK; aun así alguien experto puede analizarla, por lo que no debe considerarse completamente protegida.
- El código y el flujo de compilación no han sido probados físicamente en Android todavía: el objetivo es obtener una primera APK de prueba.

## Android Studio (alternativa)

- Instala Android Studio y un SDK Android 35 con Java 17.
- Abre el proyecto. Como este paquete **no incluye wrapper ejecutable** (`gradlew`, `gradlew.bat`, `gradle-wrapper.jar`), puedes crear un proyecto Android nuevo primero y copiar `app/src/main` y los Gradle del paquete, o instalar Gradle 8.9 por separado.
- Ejecuta `:app:assembleDebug`. El resultado estará en `app/build/outputs/apk/debug/app-debug.apk`.

## Qué tienes que mantener en privado

Tu repositorio, el código fuente y las futuras claves de firma. A tus compañeros envía solo el APK.
